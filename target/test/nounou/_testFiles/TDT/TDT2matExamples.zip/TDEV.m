classdef TDEV < handle
%TDEV  TDevAccX wrapper
%   obj = TDEV() connects to Workbench server
%
%   obj.TD   TDevAccX object
%
%   obj = TDT('parameter',value,...)
%   'parameter', value pairs
%      'SERVER'     string, data tank server (default 'Local')
%
    properties
        % default parameters
        SERVER = 'Local';
        DEVICE_NAME = '';
    end
    properties (SetAccess=private)
       TD;
       DEVICE_NAMES = {};
       DEVICE_TYPES = {};
       DEVICE_RCOS = {};
       DEVICE_TYPE = '';
       PARTAG = {};
       MODE = 0;
       FS = {};
       TANK = '';
       MODES = {'Idle', 'Standby', 'Preview', 'Run'};
    end
    
    methods (Access=private)            
        function obj = setup(obj)
            % create map of tags and their sizes for all devices
            types = [68 73 76 80 83 65];
            obj.PARTAG = {};
            obj.FS = {};
            ind1 = 1;
            for nm = obj.DEVICE_NAMES
                nm = nm{1};
                obj.PARTAG{ind1} = {};
                ind2 = 1;
                for i = types
                    tag_name = obj.TD.GetNextTag(nm, i, 1);
                    while ~strcmp(tag_name, '')
                        tn = [nm '.' tag_name];
                        obj.PARTAG{ind1}{ind2}.tag_size = obj.TD.GetTargetSize(tn);
                        obj.PARTAG{ind1}{ind2}.tag_type = char(obj.TD.GetTargetType(tn));
                        obj.PARTAG{ind1}{ind2}.tag_name = tag_name;
                        tag_name = obj.TD.GetNextTag(nm, i, 0);
                        ind2 = ind2 + 1;
                    end
                end
                obj.FS = cat(2, obj.FS, obj.TD.GetDeviceSF(nm));
                ind1 = ind1 + 1;
            end
        end
        
        function obj = set_mode(obj, new_mode)
            mode_str = obj.MODES{new_mode+1};
            obj.MODE = obj.TD.GetSysMode();
            if new_mode == obj.MODE
                warning(['Workbench is already in ' mode_str ' mode']);
                return
            end
            disp(['Switching to ' mode_str ' mode'])
            obj.TD.SetSysMode(new_mode);
            ct = 0; tic;
            while obj.TD.GetSysMode ~= new_mode
                pause(.1); ct = ct + 1;
                if ct >= 50 && ~mod(ct,20)
                    warning('System mode hasn''t changed after %.1f seconds', toc);
                end
            end
            if new_mode > 0    
                obj.setup();
            end
            obj.MODE = new_mode;
        end
    end
    
    methods
        
        function obj = TDEV(varargin)
            if nargin > 1
                % parse varargin
                for i = 1:2:length(varargin)
                    eval(['obj.' upper(varargin{i}) '=varargin{i+1};']);
                end
            end
            
            % variable for the ActiveX wrapper interface
            obj.TD = actxserver('TDevAcc.X');
            
            % Then connect to a server
            if obj.TD.ConnectServer('Local') ~= 1
                error('%s OpenEx server not found', obj.SERVER);
            end

            device_name = obj.TD.GetDeviceName(0);
            obj.DEVICE_NAMES = {};
            obj.DEVICE_RCOS = {};
            obj.DEVICE_TYPES = {};
            ind = 1;
            while ~strcmp(device_name,'')
                obj.DEVICE_TYPE = obj.TD.GetDeviceType(device_name);
                obj.DEVICE_TYPES = cat(2, obj.DEVICE_TYPES, obj.DEVICE_TYPE);
                obj.DEVICE_RCOS = cat(2, obj.DEVICE_RCOS, obj.TD.GetDeviceRCO(obj.DEVICE_NAME));
                obj.DEVICE_NAMES = cat(2, obj.DEVICE_NAMES, device_name);
                
                ind = ind + 1;
                device_name = obj.TD.GetDeviceName(ind);
            end
            if strcmp(obj.DEVICE_NAME,'')
                obj.DEVICE_NAME = obj.DEVICE_NAMES{1};
            end
            disp(['using Workbench device ' obj.DEVICE_NAME]);
            obj.MODE = obj.TD.GetSysMode();
            if obj.MODE > 1
                obj.setup();
            end
            obj.TANK = obj.TD.GetTankName();
        end

        function obj = preview(obj)
            obj.set_mode(2);
        end
        
        function obj = run(obj)
            obj.set_mode(3);
        end
        
        function obj = idle(obj)
            obj.set_mode(0);
        end
        
        function obj = standby(obj)
            obj.set_mode(1);
        end

        function result = status(obj)
            result = obj.TD.CheckServerConnection();
        end
        
        function obj = set_tank(obj, new_tank)
            if obj.MODE > 1
                warning('Workbench is running and can''t change tank, switch to Idle or Standby first');
                return
            end
            result = obj.TD.SetTankName(new_tank);
            if result == 1
                obj.TANK = new_tank;
                disp(['New tank name is ' obj.TANK]);
            else
                disp('Error setting new tank name');
            end
        end
        
        function result = write(obj, tagname, value, varargin)
            %TDT.write  writes a value to a parameter tag on hardware
            %   result = TDT.write(TAGNAME, VALUE), where TAGNAME and VALUE
            %   are strings, write the value(s) to parameter tag
            %
            %   result   1 if successful, 0 otherwise
            %
            %   TDT.write(TAGNAME,VALUE,'parameter',value,...)
            %
            %   'parameter', value pairs
            %      'DEVICE'  string, name of device.  if missing, the
            %                  previously used device_name will be used.  
            %                  if set, this will become the new default
            %      'FORMAT'  string, destination format (array only) 
            %                  options are 'F32' (default) 'I32' 'I16' 'I8'
            %      'OFFSET'  scalar, offset into buffer (array only).
            %                  default is 0.
            %

            % defaults
            FORMAT = 'F32';
            OFFSET = 0;
            DEVICE = obj.DEVICE_NAME;
            old_device_name = obj.DEVICE_NAME;
            
            % parse varargin
            for i = 1:2:length(varargin)
                eval([upper(varargin{i}) '=varargin{i+1};']);
            end
            
            obj.DEVICE_NAME = DEVICE;
            
            % check if device name exists
            target = -1;
            for i = 1:numel(obj.DEVICE_NAMES)
                if strcmp(obj.DEVICE_NAMES{i}, DEVICE)
                    target = i;
                end
            end
            if target == -1
                obj.DEVICE_NAME = old_device_name;
                error('Device %s not found', DEVICE);
            end
            
            % check if tagname is in PARTAG property and get array size
            tags = obj.PARTAG{i};
            tagind = -1;
            for i = 1:numel(tags)
                if strcmp(tags{i}.tag_name, tagname)
                    tagind = i;
                    sz = tags{i}.tag_size;
                    break;
                end
            end
            if tagind == -1
                error('Tag name %s not found', tagname);
            end
            
            %if array is not a row, make it a row
            if iscolumn(value)
                value = value';
            end
            if ~isrow(value)
                error('array must be single row or column')
            end
            
            if numel(value) > sz
                error('Number of elements (%d) larger than tag %s can hold (%d)', numel(value), tagname, tags{i}.tag_size);
            end
                    
            target = [obj.DEVICE_NAME '.' tagname];
            if isscalar(value)
                result = obj.TD.SetTargetVal(target, value);
            else
                if OFFSET > sz
                    error('Offset (%d) larger than %s tag size (%d)', OFFSET, tagname, tags{i}.tag_size);
                end
                result = obj.TD.WriteTargetVEX(target, OFFSET, FORMAT, value);
            end
        end
        
        function value = read(obj, tagname, varargin)
            %value = TDT.read(  writes a value to a parameter tag in RCX file
            %   value = TDT.read(TAGNAME), where TAGNAME is a string, reads
            %   the values from parameter tag
            %
            %   value   read value(s)
            %
            %   TDT.read(TAGNAME,'parameter',value,...)
            %
            %   'parameter', value pairs
            %      'DEVICE'  string, name of device.  if missing, the
            %                  previously used device_name will be used.  
            %                  if set, this will become the new default
            %      'SOURCE'  string, source format (array only) 
            %                  options are 'F32' (default) 'I32' 'I16' 'I8'
            %      'DEST'    string, destination format (array only) 
            %                  options are 'F64' 'F32' (default) 'I32' 'I16' 'I8'
            %      'SIZE'    scalar, number of words to read (array only).
            %                  default is the entire buffer.
            %      'OFFSET'  scalar, offset into buffer (array only).
            %                  default is 0.
            %      'NCHAN'   scalar, number of channels in buffer (array
            %                 only). used for de-interlacing data. default
            %                 is 1.
            %
            
             % defaults
            SOURCE = 'F32';
            DEST = 'F32';
            SIZE = -1;
            OFFSET = 0;
            NCHAN = 1;
            DEVICE = obj.DEVICE_NAME;
            old_device_name = obj.DEVICE_NAME;
            
            % parse varargin
            for i = 1:2:length(varargin)
                eval([upper(varargin{i}) '=varargin{i+1};']);
            end
            
            obj.DEVICE_NAME = DEVICE;
            
            % check if device name exists
            target = -1;
            for i = 1:numel(obj.DEVICE_NAMES)
                if strcmp(obj.DEVICE_NAMES{i}, DEVICE)
                    target = i;
                end
            end
            if target == -1
                obj.DEVICE_NAME = old_device_name;
                error('Device %s not found', DEVICE);
            end
            
            % check if tagname is in PARTAG property and get array size
            tags = obj.PARTAG{i};
            tagind = -1;
            for i = 1:numel(tags)
                if strcmp(tags{i}.tag_name, tagname)
                    tagind = i;
                    if SIZE == -1
                        SIZE = tags{i}.tag_size - OFFSET;
                    end
                    break;
                end
            end
            if tagind == -1
                error('Tag name %s not found', tagname);
            end
            
            if OFFSET > SIZE
                error('Offset (%d) > %s tag size (%d)', OFFSET, tagname, SIZE);
            end
            
            % do the actual reading
            tag = [obj.DEVICE_NAME '.' tagname];
            value = obj.TD.ReadTargetVEX(tag, OFFSET, SIZE, SOURCE, DEST);
        end
        
        function delete(obj)
            obj.TD.CloseConnection();
        end
    end
end